#In Python, function is a group of related statements that perform a specific task.
#Function Declaration


def GreetMe(name):
    print("Good Morning"+name)
    #Function Call


def AddIntegers(a, b):
    return a+b


GreetMe("Rahul Shetty")

print(AddIntegers(2, 3))









